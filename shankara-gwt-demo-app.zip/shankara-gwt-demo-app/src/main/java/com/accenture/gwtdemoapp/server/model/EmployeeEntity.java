package com.accenture.gwtdemoapp.server.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * @author shankara
 *
 */
@Entity
@Table(name = "EMPLOYEE_INFO")
public class EmployeeEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long employeeId;
	
	@Column(name = "EMPLOYEE_NAME")
	private String employeeName;
	
	@Column(name = "EMPLOYEE_AGE")
	private int employeeAge;
	
	@Column(name = "EMPLOYEE_GENDER")
	private String employeeGender;
	
	@Column(name = "EMPLOYEE_LOCATION")
	private String employeeLocation;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "EMPLOYEE_DOB")
	private Date employeeDOB;

	/**
	 * @return the employeeId
	 */
	public Long getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the employeeAge
	 */
	public int getEmployeeAge() {
		return employeeAge;
	}

	/**
	 * @param employeeAge the employeeAge to set
	 */
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}

	/**
	 * @return the employeeGender
	 */
	public String getEmployeeGender() {
		return employeeGender;
	}

	/**
	 * @param employeeGender the employeeGender to set
	 */
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}

	/**
	 * @return the employeeLocation
	 */
	public String getEmployeeLocation() {
		return employeeLocation;
	}

	/**
	 * @param employeeLocation the employeeLocation to set
	 */
	public void setEmployeeLocation(String employeeLocation) {
		this.employeeLocation = employeeLocation;
	}

	/**
	 * @return the employeeDOB
	 */
	public Date getEmployeeDOB() {
		return employeeDOB;
	}

	/**
	 * @param employeeDOB the employeeDOB to set
	 */
	public void setEmployeeDOB(Date employeeDOB) {
		this.employeeDOB = employeeDOB;
	}
}
