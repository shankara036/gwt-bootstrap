package com.accenture.gwtdemoapp.client;

import com.accenture.gwtdemoapp.service.EmployeeOpsServiceImpl;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.ui.RootPanel;

/**
 * @author shankara
 * 
 * Entry point classes define <code>onModuleLoad()</code>.
 */
public class GwtMavenDemoApp implements EntryPoint {
  @Override
	public void onModuleLoad() {
		EmployeeOpsServiceImpl employee = new EmployeeOpsServiceImpl(GWT.getModuleBaseURL() + "gwtdemoapp");
		RootPanel.get().add(employee.getMainGUI());	
	}
}
