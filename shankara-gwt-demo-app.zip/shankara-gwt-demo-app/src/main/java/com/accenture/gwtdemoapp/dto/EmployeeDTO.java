package com.accenture.gwtdemoapp.dto;

import java.io.Serializable;
import java.util.Date;

/**
 * @author shankara
 *
 */
public class EmployeeDTO implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private Long employeeId;
	private String employeeName;
	private Integer employeeAge;
	private String employeeGender;
	private String employeeLocation;
	private Date employeeDOB;
	
	public EmployeeDTO() {}

	public EmployeeDTO(String employeeName, Integer employeeAge, String employeeGender, String employeeLocation, Date employeeDOB) {
		super();
		this.employeeName = employeeName;
		this.employeeAge = employeeAge;
		this.employeeGender = employeeGender;
		this.employeeLocation = employeeLocation;
		this.employeeDOB = employeeDOB;
	}

	/**
	 * @return the employeeId
	 */
	public Long getEmployeeId() {
		return employeeId;
	}

	/**
	 * @param employeeId the employeeId to set
	 */
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	/**
	 * @return the employeeName
	 */
	public String getEmployeeName() {
		return employeeName;
	}

	/**
	 * @param employeeName the employeeName to set
	 */
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	/**
	 * @return the employeeAge
	 */
	public Integer getEmployeeAge() {
		return employeeAge;
	}

	/**
	 * @param employeeAge the employeeAge to set
	 */
	public void setEmployeeAge(Integer employeeAge) {
		this.employeeAge = employeeAge;
	}

	/**
	 * @return the employeeGender
	 */
	public String getEmployeeGender() {
		return employeeGender;
	}

	/**
	 * @param employeeGender the employeeGender to set
	 */
	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}

	/**
	 * @return the employeeLocation
	 */
	public String getEmployeeLocation() {
		return employeeLocation;
	}

	/**
	 * @param employeeLocation the employeeLocation to set
	 */
	public void setEmployeeLocation(String employeeLocation) {
		this.employeeLocation = employeeLocation;
	}

	/**
	 * @return the employeeDOB
	 */
	public Date getEmployeeDOB() {
		return employeeDOB;
	}

	/**
	 * @param employeeDOB the employeeDOB to set
	 */
	public void setEmployeeDOB(Date employeeDOB) {
		this.employeeDOB = employeeDOB;
	}	
}
