package com.accenture.gwtdemoapp.clientgui;

import java.util.Date;
import java.util.List;

import com.accenture.gwtdemoapp.dto.EmployeeDTO;
import com.accenture.gwtdemoapp.service.EmployeeOpsServiceImpl;
import com.google.gwt.cell.client.DateCell;
import com.google.gwt.core.client.GWT;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.cellview.client.CellTable;
import com.google.gwt.user.cellview.client.Column;
import com.google.gwt.user.cellview.client.HasKeyboardSelectionPolicy.KeyboardSelectionPolicy;
import com.google.gwt.user.cellview.client.SimplePager;
import com.google.gwt.user.cellview.client.SimplePager.TextLocation;
import com.google.gwt.user.cellview.client.TextColumn;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.FlexTable.FlexCellFormatter;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DateBox;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SingleSelectionModel;

/**
 * @author shankara
 *
 */
public class MainGUI extends Composite {

	private VerticalPanel mainPanel = new VerticalPanel();
	private HorizontalPanel hpanel1 = new HorizontalPanel();

	private Label employeeNameLabel;
	private Label employeeAgeLabel;
	private Label employeeSexLabel;
	private Label employeeLocationLabel;
	private Label employeeDateOfBirthLabel;
	private Label employeeOpsError;

	private TextBox employeeNameText;
	private TextBox employeeAgeText;
	private Button employeeAddButton;
	private Button employeeDeleteButton;

	private ListBox listBox1;
	private DateBox dateBox;

	private Label resultLbl;
	private EmployeeOpsServiceImpl serviceImpl;
	CellTable<EmployeeDTO> table;
	RadioButton radioButton1;
	RadioButton radioButton2;

	private EmployeeDTO employee;
	private EmployeeDTO selectedEmployee;
	final SingleSelectionModel<EmployeeDTO> selectionModel;
	private SimplePager pager;
	ListDataProvider<EmployeeDTO> dataProvider;

	public MainGUI(EmployeeOpsServiceImpl serviceImpl) {
		initWidget(mainPanel);
		this.serviceImpl = serviceImpl;
		serviceImpl.getEmployees();
		this.resultLbl = new Label("");
		this.mainPanel.add(resultLbl);

		this.employeeOpsError = new Label("");
		employeeOpsError.setStyleName("serverResponseLabelError");
		this.mainPanel.add(employeeOpsError);

		this.employeeNameLabel = new Label("Employee Name");
		this.employeeNameText = new TextBox();

		this.employeeAgeLabel = new Label("Employee Age");
		this.employeeAgeText = new TextBox();

		this.employeeSexLabel = new Label("Employee Gender");
		radioButton1 = new RadioButton("radioGroup", "Male");
		radioButton2 = new RadioButton("radioGroup", "Female");
		radioButton1.setValue(true);

		this.employeeLocationLabel = new Label("Employee Location");
		listBox1 = new ListBox();
		listBox1.addItem("India");
		listBox1.addItem("Singapore");
		listBox1.addItem("USA");
		listBox1.addItem("London");
		listBox1.addItem("Germany");
		listBox1.setVisibleItemCount(1);
		listBox1.setWidth("100%");

		this.employeeDateOfBirthLabel = new Label("Employee Date Of Birth");
		DateTimeFormat dateFormat = DateTimeFormat.getFormat("MM/dd/yyyy");
		dateBox = new DateBox();
		dateBox.setFormat(new DateBox.DefaultFormat(dateFormat));

		FlexTable layout = new FlexTable();
		layout.setCellSpacing(6);
		FlexCellFormatter cellFormatter = layout.getFlexCellFormatter();

		layout.setWidget(0, 0, employeeNameLabel);
		layout.setWidget(0, 1, employeeNameText);
		cellFormatter.setColSpan(0, 1, 2);
		layout.setWidget(1, 0, employeeAgeLabel);
		layout.setWidget(1, 1, employeeAgeText);
		cellFormatter.setColSpan(1, 1, 2);
		layout.setWidget(2, 0, employeeSexLabel);
		layout.setWidget(2, 1, radioButton1);
		layout.setWidget(2, 2, radioButton2);
		layout.setWidget(3, 0, employeeLocationLabel);
		layout.setWidget(3, 1, listBox1);
		cellFormatter.setColSpan(3, 1, 2);
		layout.setWidget(4, 0, employeeDateOfBirthLabel);
		layout.setWidget(4, 1, dateBox);
		cellFormatter.setColSpan(4, 1, 2);

		DecoratorPanel decoratorPanel = new DecoratorPanel();

		decoratorPanel.add(layout);
		this.mainPanel.add(decoratorPanel);

		this.mainPanel.setSpacing(10);
		this.employeeAddButton = new Button("Add Employee");
		employeeAddButton.addClickHandler(new AddButtonClickHandler());
		this.employeeDeleteButton = new Button("Delete Employee");
		employeeDeleteButton.addClickHandler(new DeleteButtonClickHandler());

		this.mainPanel.setSpacing(10);

		// Create a CellTable.
		table = new CellTable<EmployeeDTO>();
		table.setKeyboardSelectionPolicy(KeyboardSelectionPolicy.ENABLED);
		
		// Add a text column to show the name.
		TextColumn<EmployeeDTO> nameColumn = new TextColumn<EmployeeDTO>() {
			@Override
			public String getValue(EmployeeDTO object) {
				return object.getEmployeeName();
			}
		};
		table.addColumn(nameColumn, "Employee Name");
		// Add a date column to show the Age.
		TextColumn<EmployeeDTO> ageColumn = new TextColumn<EmployeeDTO>() {
			@Override
			public String getValue(EmployeeDTO object) {
				return String.valueOf(object.getEmployeeAge());
			}
		};
		table.addColumn(ageColumn, "Employee Age");

		// Add a text column to show the Gender.
		TextColumn<EmployeeDTO> genderColumn = new TextColumn<EmployeeDTO>() {
			@Override
			public String getValue(EmployeeDTO object) {
				return object.getEmployeeGender();
			}
		};
		table.addColumn(genderColumn, "Employee Gender");

		// Add a text column to show the Location.
		TextColumn<EmployeeDTO> locationColumn = new TextColumn<EmployeeDTO>() {
			@Override
			public String getValue(EmployeeDTO object) {
				return object.getEmployeeLocation();
			}
		};
		table.addColumn(locationColumn, "Employee Location");

		// Add a date column to show the birthday.
		DateCell dateCell = new DateCell();
		Column<EmployeeDTO, Date> dateColumn = new Column<EmployeeDTO, Date>(dateCell) {
			@Override
			public Date getValue(EmployeeDTO object) {
				return object.getEmployeeDOB();
			}
		};
		table.addColumn(dateColumn, "Employee DOB");

		// Add a selection model to handle user selection.
		selectionModel = new SingleSelectionModel<EmployeeDTO>();
		table.setSelectionModel(selectionModel);
		table.setEmptyTableWidget(new Label(" No Records Found"));

		dataProvider = new ListDataProvider<EmployeeDTO>();
		dataProvider.addDataDisplay(table);

		selectionModel.addSelectionChangeHandler(new SelectionChangeEventHandler());
		VerticalPanel panel = new VerticalPanel();
		panel.setBorderWidth(1);
		panel.setWidth("400");
		panel.add(table);
		mainPanel.add(panel);
		// Create a Pager to control the table.
		SimplePager.Resources pagerResources = GWT.create(SimplePager.Resources.class);
		pager = new SimplePager(TextLocation.CENTER, pagerResources, false, 0, true);
		pager.setDisplay(table);
		pager.setPageSize(5);

		hpanel1.add(pager);
		hpanel1.add(employeeAddButton);
		hpanel1.setSpacing(10);
		hpanel1.add(employeeDeleteButton);
		employeeDeleteButton.setEnabled(false);
		mainPanel.add(hpanel1);
		mainPanel.getElement().setAttribute("align", "center");
	}

	public void updateLabel(String greetings) {
		this.employeeOpsError.setText(greetings);
		this.employeeNameText.setValue(null);
		this.employeeAgeText.setValue(null);
		this.dateBox.setValue(null);
		this.listBox1.setItemSelected(0, true);
		radioButton1.setValue(true);
		serviceImpl.getEmployees();
	}

	public void updateErrorLabel(String greetings) {
		this.employeeOpsError.setText(greetings);
	}

	public void updateLabel2(List<EmployeeDTO> employeedto2) {
		if (null != employeedto2) {
			table.setRowCount(employeedto2.size(), true);
			table.setRowData(0, employeedto2);
			dataProvider.setList(employeedto2);
		}
	}

	private class AddButtonClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			employee = new EmployeeDTO();
			employee.setEmployeeName(employeeNameText.getText());
			employee.setEmployeeAge(Integer.valueOf(employeeAgeText.getText()));
			employee.setEmployeeLocation(listBox1.getValue(listBox1.getSelectedIndex()));
			employee.setEmployeeDOB(dateBox.getValue());
			employee.setEmployeeGender(radioButton1.getValue() ? "Male" : "Female");
			serviceImpl.addEmployee(employee);
		}
	}

	private class DeleteButtonClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			if (null != selectedEmployee) {
				serviceImpl.deleteEmployee(selectedEmployee);
			}
		}
	}

	private class SelectionChangeEventHandler implements SelectionChangeEvent.Handler {

		@Override
		public void onSelectionChange(SelectionChangeEvent event) {
			selectedEmployee = selectionModel.getSelectedObject();
			if (selectedEmployee != null) {
				if (table.getRowCount() >= 1) {
					employeeDeleteButton.setEnabled(true);
				} else {
					employeeDeleteButton.setEnabled(false);
				}
			}
		}
	}
}
