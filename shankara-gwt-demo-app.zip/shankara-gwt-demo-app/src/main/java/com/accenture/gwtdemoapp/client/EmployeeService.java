package com.accenture.gwtdemoapp.client;

import java.util.List;

import com.accenture.gwtdemoapp.dto.EmployeeDTO;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * @author shankara
 *
 */
@RemoteServiceRelativePath("employeeapp")
public interface EmployeeService extends RemoteService {
	List<EmployeeDTO> getEmployees() throws Exception;
	String addEmployee(EmployeeDTO employee) throws Exception;
	String deleteEmployee(EmployeeDTO employee) throws Exception;
}
