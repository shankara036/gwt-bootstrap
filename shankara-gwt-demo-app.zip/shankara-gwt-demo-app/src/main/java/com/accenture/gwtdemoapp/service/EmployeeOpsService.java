package com.accenture.gwtdemoapp.service;

import com.accenture.gwtdemoapp.dto.EmployeeDTO;

/**
 * @author shankara
 *
 */
public interface EmployeeOpsService {
	void getEmployees();
	void addEmployee(EmployeeDTO employee);
	void deleteEmployee(EmployeeDTO employee);
}