package com.accenture.gwtdemoapp.dao;

import java.lang.reflect.ParameterizedType;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

/**
 * @author shankara
 *
 * @param <K>
 * @param <E>
 */
public abstract class AbstractHibernateJpaDAO<K, E> {

	protected Class<E> entityClass;

	@SuppressWarnings("unchecked")
	public AbstractHibernateJpaDAO() {
		ParameterizedType genericSuperclass = (ParameterizedType) getClass().getGenericSuperclass();
		entityClass = (Class<E>) genericSuperclass.getActualTypeArguments()[1];
	}

	public void persist(E entity) {
		getEntityManager().getTransaction().begin();
		getEntityManager().persist(entity);
		getEntityManager().getTransaction().commit();
	}

	public void remove(E entity) {
		getEntityManager().getTransaction().begin();
		getEntityManager().remove(entity);
		getEntityManager().flush();
		getEntityManager().getTransaction().commit();
	}

	public void refresh(E entity) {
		getEntityManager().refresh(entity);
	}

	public E merge(E entity) {
		return getEntityManager().merge(entity);
	}

	public E findById(K id) {
		return getEntityManager().find(entityClass, id);
	}

	public E flush(E entity) {
		getEntityManager().flush();
		return entity;
	}

	@SuppressWarnings("unchecked")
	public List<E> findAll() {
		String queryStr = "SELECT h FROM " + entityClass.getName() + " h";
		Query query = getEntityManager().createQuery(queryStr, entityClass);
		List<E> resultList = query.getResultList();
		return resultList;
	}

	public Integer removeAll() {
		String queryStr = "DELETE FROM " + entityClass.getName() + " h";
		Query query = getEntityManager().createQuery(queryStr);
		return query.executeUpdate();
	}

	protected abstract EntityManager getEntityManager();
}
