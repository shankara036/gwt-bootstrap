package com.accenture.gwtdemoapp.service;

import java.util.List;

import com.accenture.gwtdemoapp.client.EmployeeService;
import com.accenture.gwtdemoapp.client.EmployeeServiceAsync;
import com.accenture.gwtdemoapp.clientgui.MainGUI;
import com.accenture.gwtdemoapp.dto.EmployeeDTO;
import com.google.gwt.core.shared.GWT;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.rpc.ServiceDefTarget;

/**
 * @author shankara
 *
 */
public class EmployeeOpsServiceImpl implements EmployeeOpsService {

	private EmployeeServiceAsync service;
	private MainGUI maingui;

	public EmployeeOpsServiceImpl(String url) {
		this.service = GWT.create(EmployeeService.class);
		ServiceDefTarget endpoint = (ServiceDefTarget) this.service;
		endpoint.setServiceEntryPoint(url);
		this.maingui = new MainGUI(this);
	}
	
	public MainGUI getMainGUI() {
		return this.maingui;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void getEmployees() {
		this.service.getEmployees(new DefaultCallback());;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void addEmployee(EmployeeDTO employee) {
		this.service.addEmployee(employee, new DefaultCallback());
	}

	@SuppressWarnings("unchecked")
	@Override
	public void deleteEmployee(EmployeeDTO employee) {
		this.service.deleteEmployee(employee, new DefaultCallback());
	}
	
	@SuppressWarnings("rawtypes")
	private class DefaultCallback implements AsyncCallback {

		@Override
		public void onFailure(Throwable caught) {
			maingui.updateLabel("error");
		}

		@SuppressWarnings("unused")
		@Override
		public void onSuccess(Object result) {
			if (result instanceof String) {
				String greeting = (String) result;
				if (greeting.contains("cannot")) {
					maingui.updateErrorLabel(greeting);
				} else {
					maingui.updateLabel(greeting);
				}
			} else if (result instanceof Integer) {
				int sum = (Integer) result;
			} else if (result instanceof List) {
				@SuppressWarnings("unchecked")
				List<EmployeeDTO> clientdto = ((List<EmployeeDTO>) result);
				maingui.updateLabel2(clientdto);
			}
		}
	}
}
