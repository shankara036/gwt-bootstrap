package com.accenture.gwtdemoapp.server;

import java.util.ArrayList;
import java.util.List;

import com.accenture.gwtdemoapp.client.EmployeeService;
import com.accenture.gwtdemoapp.dao.EmployeeDAO;
import com.accenture.gwtdemoapp.dto.EmployeeDTO;
import com.accenture.gwtdemoapp.server.model.EmployeeEntity;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

/**
 * @author shankara
 * 
 * The server side implementation of the RPC service.
 */
public class EmployeeServiceImpl extends RemoteServiceServlet implements EmployeeService {
	
	private static final long serialVersionUID = 1L;

	private static EmployeeDAO employeeDAO = new EmployeeDAO();
	
	@Override
	public List<EmployeeDTO> getEmployees() throws Exception {
		List<EmployeeDTO> employees = new ArrayList<>();
		for(EmployeeEntity emp : employeeDAO.findAll()) {
			EmployeeDTO employee = new EmployeeDTO();
			employee.setEmployeeId(emp.getEmployeeId());
			employee.setEmployeeName(emp.getEmployeeName());
			employee.setEmployeeAge(emp.getEmployeeAge());
			employee.setEmployeeGender(emp.getEmployeeGender());
			employee.setEmployeeLocation(emp.getEmployeeLocation());
			employee.setEmployeeDOB(emp.getEmployeeDOB());
			employees.add(employee);
		}
		return employees;
	}

	@Override
	public String addEmployee(EmployeeDTO emp) throws Exception {
		EmployeeEntity employeeEntity = new EmployeeEntity();
		employeeEntity.setEmployeeName(emp.getEmployeeName());
		employeeEntity.setEmployeeAge(emp.getEmployeeAge());
		employeeEntity.setEmployeeGender(emp.getEmployeeGender());
		employeeEntity.setEmployeeLocation(emp.getEmployeeLocation());
		employeeEntity.setEmployeeDOB(emp.getEmployeeDOB());
		employeeDAO.persist(employeeEntity);
		return "Success";
	}

	@Override
	public String deleteEmployee(EmployeeDTO emp) throws Exception {
		EmployeeEntity employee = employeeDAO.findById(emp.getEmployeeId());
		employeeDAO.remove(employee);
		return "Success";
	}
}