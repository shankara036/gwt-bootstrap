package com.accenture.gwtdemoapp.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.accenture.gwtdemoapp.server.model.EmployeeEntity;

/**
 * @author shankara
 *
 */
public class EmployeeDAO extends AbstractHibernateJpaDAO<Long, EmployeeEntity> {

	private static EntityManager entityManager;
	
	static {
		EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("MyPUnit");
		entityManager = entityManagerFactory.createEntityManager();
	}
	
	@Override
	protected EntityManager getEntityManager() {
		return entityManager;
	}
}
